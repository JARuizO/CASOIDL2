﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplicationIDL2.Migrations
{
    /// <inheritdoc />
    public partial class Inicia4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
